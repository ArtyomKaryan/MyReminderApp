package artyom.karyan.reminderapp

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.os.Bundle
import android.widget.*
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.work.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

class AddReminderActivity : AppCompatActivity() {

    private val viewModel: ReminderViewModel by viewModels()
    private var selectedCalendar = Calendar.getInstance()
    private lateinit var tvSelectedTime: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_reminder)

        val etTitle = findViewById<EditText>(R.id.etTitle)
        val btnPickTime = findViewById<Button>(R.id.btnPickTime)
        tvSelectedTime = findViewById(R.id.tvSelectedTime)
        val spinnerFrequency = findViewById<Spinner>(R.id.spinnerFrequency)
        val btnSave = findViewById<Button>(R.id.btnSave)

        btnPickTime.setOnClickListener {
            val datePicker = DatePickerDialog(this, { _, year, month, day ->
                selectedCalendar.set(Calendar.YEAR, year)
                selectedCalendar.set(Calendar.MONTH, month)
                selectedCalendar.set(Calendar.DAY_OF_MONTH, day)

                TimePickerDialog(this, { _, hour, minute ->
                    selectedCalendar.set(Calendar.HOUR_OF_DAY, hour)
                    selectedCalendar.set(Calendar.MINUTE, minute)
                    selectedCalendar.set(Calendar.SECOND, 0)

                    tvSelectedTime.text = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
                        .format(selectedCalendar.time)
                }, selectedCalendar.get(Calendar.HOUR_OF_DAY), selectedCalendar.get(Calendar.MINUTE), true).show()
            }, selectedCalendar.get(Calendar.YEAR), selectedCalendar.get(Calendar.MONTH), selectedCalendar.get(Calendar.DAY_OF_MONTH))
            datePicker.show()
        }

        btnSave.setOnClickListener {
            val title = etTitle.text.toString()
            if (title.isEmpty()) {
                Toast.makeText(this, "Please enter a title", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val timeInMs = selectedCalendar.timeInMillis
            if (timeInMs <= System.currentTimeMillis()) {
                Toast.makeText(this, "Please select a future time", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val frequency = spinnerFrequency.selectedItem.toString()

            val newReminder = Reminder(title = title, dateTime = timeInMs, frequency = frequency)
            
            // Օգտագործում ենք lifecycleScope insert-ի համար, որ ստանանք ID-ն
            lifecycleScope.launch {
                val newId = viewModel.insert(newReminder)
                scheduleWork(newId, title, timeInMs, frequency)
                finish()
            }
        }
    }

    private fun scheduleWork(reminderId: Long, title: String, timeInMs: Long, frequency: String) {
        val userEmail = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
            .getString("user_email", "") ?: ""

        val data = Data.Builder()
            .putString("title", title)
            .putString("email", userEmail)
            .build()

        val delay = timeInMs - System.currentTimeMillis()
        val tag = reminderId.toString()

        when (frequency) {
            "Daily" -> {
                val periodicWork = PeriodicWorkRequestBuilder<NotificationWorker>(1, TimeUnit.DAYS)
                    .setInitialDelay(delay, TimeUnit.MILLISECONDS)
                    .setInputData(data)
                    .addTag(tag)
                    .build()
                WorkManager.getInstance(this).enqueue(periodicWork)
            }
            "Weekly" -> {
                val periodicWork = PeriodicWorkRequestBuilder<NotificationWorker>(7, TimeUnit.DAYS)
                    .setInitialDelay(delay, TimeUnit.MILLISECONDS)
                    .setInputData(data)
                    .addTag(tag)
                    .build()
                WorkManager.getInstance(this).enqueue(periodicWork)
            }
            else -> {
                val oneTimeWork = OneTimeWorkRequestBuilder<NotificationWorker>()
                    .setInitialDelay(delay, TimeUnit.MILLISECONDS)
                    .setInputData(data)
                    .addTag(tag)
                    .build()
                WorkManager.getInstance(this).enqueue(oneTimeWork)
            }
        }
    }
}
