package artyom.karyan.reminderapp

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "reminders")
data class Reminder(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val dateTime: Long, // Պահում ենք Milliseconds-ով
    val frequency: String // "Once", "Daily", "Weekly"
)
